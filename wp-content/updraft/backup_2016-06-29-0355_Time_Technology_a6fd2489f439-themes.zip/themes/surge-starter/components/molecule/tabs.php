 
<?php debug('Tabs: Element coming soon.'); ?> 