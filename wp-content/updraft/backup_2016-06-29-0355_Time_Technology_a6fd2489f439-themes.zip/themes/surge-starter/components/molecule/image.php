<div class="<?php echo $vars['class'] ?> "> 
        <img src="<?php echo $vars['image']; ?>" width="100%" ></img> 
</div> 