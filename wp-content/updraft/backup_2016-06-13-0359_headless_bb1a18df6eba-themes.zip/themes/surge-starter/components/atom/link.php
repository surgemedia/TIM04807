<?php if (strlen($vars['text'])) : ?>
	<a class="<?php echo $vars['class'] ?>" href="<?php echo $vars['link'] ?>"><?php echo $vars['text']; ?>
	</a>
<?php endif ?>