<div class="<?php echo $vars['class'] ?> ">
        <img alt="<?php echo $vars['title']; ?>" class="" src="<?php echo $vars['img']; ?>" width="auto" height="100"></img>
        	<p><?php echo $vars['content']; ?></p>
            <span class="text-center col-xs-12">
                <?php echo $vars['title'] ?>
            </span>
</div>