<?php get_template_part('components/molecule/content-single', get_post_type()); ?>
