# BEA ACF Reusable Field Group 1.0.0

This is a fork-like from : https://github.com/mvpdesign/acf-reusable-field-group
The purpose is to expend the way of using the mvpdesign/acf-reusable-field-group plugin by adding a fake option page that permit to reuse field groups everywhere and especially in ACF flexible & repeater fields.

To work, it requires :
 - ACF Reusable field group : https://github.com/mvpdesign/acf-reusable-field-group
 - ACF PRO : https://www.advancedcustomfields.com/pro/