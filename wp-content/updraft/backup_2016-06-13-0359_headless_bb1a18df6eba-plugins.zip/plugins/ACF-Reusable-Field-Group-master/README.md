# ACF Reusable Field Group 1.0.2

This is a plugin which adds a Reusable Field Group type to the Advanced Custom Fields WordPress Plugins.  This allows you to create a group of fields once, and reuse it within any other field group.

This plugins was created using the [Advanced Custom Fields field type template repository](https://github.com/elliotcondon/acf-field-type-template).  As such, there is a bunch of boilerplate code that is not currently used.

For more information about that process a new field type, please read [this article](http://www.advancedcustomfields.com/resources/tutorials/creating-a-new-field-type/).